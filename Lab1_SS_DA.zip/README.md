#GMP y factoriales

##Compilando

Se compila usando el siguiente codigo en la terminal, se requiere la librería gmp para ello.

  `g++ main.cpp -lgmp`

Se ejecuta con

  `./a.out n r metodo`

Donde n y r son los valores de la función C(n,r) y metodo el método elegido para encontrar el resultado de la función.

##Ejecuntado script
El script para gráficar se debe ejecutar con

  `bash data.sh`

Esto va a generar 3 tipos de gráficos de disintos.

 - n fijo y r crece hasta n
 - r fijo y n va desde r hasta n
 - n fijo y r siendo constantemente multiplicado por k hasta n


Link del repositorio git: https://github.com/daniloabella18/Mate-Compu-the-beginnings
